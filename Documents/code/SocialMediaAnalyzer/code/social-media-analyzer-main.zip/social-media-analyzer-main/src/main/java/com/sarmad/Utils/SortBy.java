package com.sarmad.Utils;

public enum SortBy {
    LIKES,
    SHARES;
}
