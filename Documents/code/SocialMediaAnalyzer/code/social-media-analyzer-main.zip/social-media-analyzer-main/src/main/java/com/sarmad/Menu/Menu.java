package com.sarmad.Menu;

public class Menu {
    public static void displayMenu() {
        System.out.println("-------------------------------------------");
        System.out.println("> Select from main menu");
        System.out.println("-------------------------------------------");
        System.out.println("1) Add a social media post");
        System.out.println("2) Delete an existing social media post");
        System.out.println("3) Retrieve a social media post");
        System.out.println("4) Retrieve the top N posts with most likes");
        System.out.println("5) Retrieve the top N posts with most shares");
        System.out.println("6) Exit");
        System.out.println("Please select: ");
    }
}
